python3 update.py && python3 bot.py
